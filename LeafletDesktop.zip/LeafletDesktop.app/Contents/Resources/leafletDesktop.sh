#!/bin/bash
open "/Applications/LeafletDesktop.app"
