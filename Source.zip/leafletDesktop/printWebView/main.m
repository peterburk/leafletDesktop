//
//  main.m
//  printWebView
//
//  Created by Peter Burkimsher on 06/07/2014.
//  Copyright (c) 2014 Peter Burkimsher. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
